﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VSCProject.Models
{
    public class Persons
    {
        [Key]
        public int Id { get; set; }
        [Column(TypeName ="VARCHAR")]
        public string Name { get; set; }
        [Column(TypeName = "VARCHAR")]
        public string Surname { get; set; }
        [Column(TypeName = "INT")]
        public int TelephoneNumber { get; set; }
        [Column(TypeName = "VARCHAR")]
        public string EmailAddress { get; set; }
        [Column(TypeName = "DATE")]
        public DateTime DateOfBirth { get; set; }

        public static implicit operator List<object>(Persons? v)
        {
            throw new NotImplementedException();
        }
    }
}
