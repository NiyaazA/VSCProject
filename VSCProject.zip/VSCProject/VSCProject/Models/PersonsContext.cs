﻿using Microsoft.EntityFrameworkCore;

namespace VSCProject.Models
{
    public class PersonsContext:DbContext
    {
        public PersonsContext(DbContextOptions<PersonsContext> options):base(options)
        {
            
        }
        public DbSet<Persons> persons { get; set; }
    }
}
